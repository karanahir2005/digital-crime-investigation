import { useState } from 'react';
import { useNav } from '@/context/NavContext';
import { MessageIcon, ScanIcon, XIcon, WorkflowSteps } from '@/components/ui';

const WORKFLOW = [
  { label: 'SMS Input', state: 'done' as const },
  { label: 'Text Extraction', state: 'active' as const },
  { label: 'Sender Check', state: 'pending' as const },
  { label: 'URL / Link Analysis', state: 'pending' as const },
  { label: 'Scam & Phishing Analysis', state: 'pending' as const },
  { label: 'AI Threat Analysis', state: 'pending' as const },
  { label: 'Risk Score', state: 'pending' as const },
  { label: 'Final Result', state: 'pending' as const },
];

const SAMPLE_SCAMS = [
  { label: 'Prize scam', text: "Congratulations! You've won a Rs.50,000 prize. Click here to claim now: http://prize-claim.xyz" },
  { label: 'Bank phishing', text: "ALERT: Your account is suspended. Verify immediately at http://fake-bank.net or call +91-XXXXXX" },
  { label: 'OTP fraud', text: "Your OTP is 847263. Never share with anyone. If not you, click: http://secure-verify.info" },
];

export default function SMSDetector() {
  const { startScan } = useNav();
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');

  function handleAnalyze(e: React.FormEvent) {
    e.preventDefault();
    startScan('sms');
  }

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in-up">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(6,182,212,0.15)', border: '1px solid rgba(6,182,212,0.3)' }}
          >
            <MessageIcon size={20} className="text-cyan-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">SMS Threat Detector</h1>
            <p className="text-sm text-slate-400">Check suspicious SMS messages for scams, phishing and malicious links.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleAnalyze}>
            <div
              className="rounded-2xl p-6 mb-5"
              style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
            >
              <h2 className="text-sm font-semibold text-slate-300 mb-5 uppercase tracking-wider">SMS Details</h2>

              <div className="flex flex-col gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Sender / Phone Number</label>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="e.g. +91 98765 43210 or BANK-ID"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-slate-400">SMS Message</label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => navigator.clipboard.readText().then(setMessage).catch(() => {})}
                        className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
                      >
                        Paste
                      </button>
                      <button
                        type="button"
                        onClick={() => setMessage('')}
                        className="text-xs text-slate-500 hover:text-slate-300 transition-colors"
                      >
                        Clear
                      </button>
                    </div>
                  </div>
                  <textarea
                    className="input-field"
                    style={{ minHeight: 160, resize: 'vertical' }}
                    placeholder="Paste the full SMS message content here..."
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                  />
                  <p className="text-xs text-slate-600 mt-1 text-right">{message.length} characters</p>
                </div>
              </div>
            </div>

            {/* Sample scams */}
            <div
              className="rounded-2xl p-5 mb-5"
              style={{ background: 'rgba(14,22,45,0.7)', border: '1px solid rgba(255,255,255,0.05)' }}
            >
              <p className="text-xs font-semibold text-slate-500 mb-3 uppercase tracking-wider">Try a sample scam</p>
              <div className="flex flex-wrap gap-2">
                {SAMPLE_SCAMS.map((s, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setMessage(s.text)}
                    className="text-xs px-3 py-1.5 rounded-full transition-all"
                    style={{ background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.2)', color: '#67e8f9' }}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="btn-primary w-full flex items-center justify-center gap-2"
              style={{ paddingTop: 15, paddingBottom: 15, borderRadius: 14, fontSize: 15 }}
            >
              <ScanIcon size={18} />
              ANALYZE SMS
            </button>
          </form>
        </div>

        {/* Sidebar */}
        <div className="flex flex-col gap-5">
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <h3 className="text-sm font-semibold text-slate-300 mb-4 uppercase tracking-wider">Analysis Workflow</h3>
            <WorkflowSteps steps={WORKFLOW} />
          </div>

          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(6,182,212,0.05)', border: '1px solid rgba(6,182,212,0.15)' }}
          >
            <h3 className="text-sm font-semibold text-cyan-300 mb-3">Common SMS Scam Patterns</h3>
            <ul className="flex flex-col gap-2">
              {[
                'Prize or lottery claims',
                'Urgent account alerts',
                'OTP or verification fraud',
                'Fake delivery notifications',
                'Job offer scams',
                'Government impersonation',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-1 h-1 rounded-full bg-cyan-400 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
