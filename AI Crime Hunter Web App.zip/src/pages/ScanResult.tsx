import { useNav, getScoreColor, getVerdictLabel } from '@/context/NavContext';
import RiskGauge from '@/components/RiskGauge';
import { StatusBadge, CheckIcon, ShieldIcon, SaveIcon, DownloadIcon, EyeIcon, MailIcon, CameraIcon, MessageIcon, ArrowRightIcon } from '@/components/ui';

export default function ScanResult() {
  const { currentResult, navigate, history } = useNav();

  const result = currentResult ?? history[0];

  if (!result) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4">
        <ShieldIcon size={40} className="text-slate-700" />
        <p className="text-slate-400">No scan result available.</p>
        <button onClick={() => navigate('email')} className="btn-primary text-sm">Start a Scan</button>
      </div>
    );
  }

  const color = getScoreColor(result.score);
  const verdict = getVerdictLabel(result.verdict);
  const TypeIcon = result.type === 'email' ? MailIcon : result.type === 'photo' ? CameraIcon : MessageIcon;

  const recommendation = result.verdict === 'safe'
    ? "Content appears safe, but remain cautious."
    : result.verdict === 'suspicious'
    ? "Do not interact with links or provide sensitive information until verified."
    : "Do not open links, download attachments or provide personal information.";

  return (
    <div className="p-8 max-w-5xl mx-auto fade-in-up">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 text-sm text-slate-400 mb-1">
            <button onClick={() => navigate('history')} className="hover:text-slate-200 transition-colors">Scan History</button>
            <span>›</span>
            <span className="text-slate-200">Result</span>
          </div>
          <h1 className="text-2xl font-black text-white">
            {result.type.toUpperCase()} ANALYSIS COMPLETE
          </h1>
        </div>
        <div className="flex gap-2">
          <button className="btn-outline flex items-center gap-2 text-sm">
            <SaveIcon size={15} /> Save
          </button>
          <button className="btn-outline flex items-center gap-2 text-sm">
            <DownloadIcon size={15} /> Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Score + verdict */}
        <div className="flex flex-col gap-5">
          {/* Score card */}
          <div
            className="rounded-2xl p-6 flex flex-col items-center text-center"
            style={{
              background: 'rgba(14,22,45,0.9)',
              border: `1px solid ${color}20`,
              boxShadow: `0 0 40px ${color}08`,
            }}
          >
            <RiskGauge score={result.score} size={150} />

            <div className="mt-4 w-full flex flex-col gap-3">
              <div
                className="flex items-center justify-between py-2 px-3 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)' }}
              >
                <span className="text-xs text-slate-500">AI Confidence</span>
                <span className="text-sm font-bold text-white">{result.confidence}%</span>
              </div>
              <div
                className="flex items-center justify-between py-2 px-3 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)' }}
              >
                <span className="text-xs text-slate-500">Threat Type</span>
                <span className="text-xs font-medium text-slate-200 text-right max-w-[120px]">{result.threatType}</span>
              </div>
              <div
                className="flex items-center justify-between py-2 px-3 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)' }}
              >
                <span className="text-xs text-slate-500">Scan Type</span>
                <div className="flex items-center gap-1.5">
                  <TypeIcon size={13} className="text-slate-400" />
                  <span className="text-xs font-medium text-slate-200 capitalize">{result.type}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Recommended action */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: result.verdict === 'safe'
                ? 'rgba(34,197,94,0.06)'
                : result.verdict === 'suspicious'
                ? 'rgba(249,115,22,0.06)'
                : 'rgba(239,68,68,0.06)',
              border: `1px solid ${color}20`,
            }}
          >
            <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color }}>
              Recommended Action
            </p>
            <p className="text-sm text-slate-300">{recommendation}</p>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2">
            <button
              onClick={() => navigate('history')}
              className="btn-primary flex items-center justify-center gap-2 text-sm"
            >
              <EyeIcon size={15} />
              View Detailed Analysis
            </button>
            <button
              onClick={() => navigate('email')}
              className="btn-outline flex items-center justify-center gap-2 text-sm"
            >
              Scan Another
              <ArrowRightIcon size={14} />
            </button>
          </div>
        </div>

        {/* Right: Indicators + explanation */}
        <div className="lg:col-span-2 flex flex-col gap-5">
          {/* Target info */}
          <div
            className="rounded-2xl px-5 py-4 flex items-center gap-3"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: `${color}18` }}
            >
              <span style={{ color }}><TypeIcon size={18} /></span>
            </div>
            <div className="min-w-0">
              <p className="text-xs text-slate-500">Analyzed target</p>
              <p className="text-sm font-medium text-slate-200 truncate">{result.target}</p>
            </div>
            <div className="ml-auto flex-shrink-0">
              <StatusBadge verdict={result.verdict} />
            </div>
          </div>

          {/* Detected indicators */}
          <div
            className="rounded-2xl p-6"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <h2 className="text-sm font-bold text-white mb-4 uppercase tracking-wider">Why was this detected?</h2>
            <div className="flex flex-col gap-2.5">
              {result.indicators.map((ind, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: `${color}18`, border: `1px solid ${color}30` }}
                  >
                    {result.verdict === 'safe'
                      ? <span style={{ color }}><CheckIcon size={11} /></span>
                      : <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
                    }
                  </div>
                  <span className="text-sm text-slate-300">{ind}</span>
                </div>
              ))}
            </div>
          </div>

          {/* AI Explanation */}
          <div
            className="rounded-2xl p-6"
            style={{
              background: 'rgba(14,22,45,0.9)',
              border: '1px solid rgba(59,130,246,0.15)',
              boxShadow: '0 0 20px rgba(59,130,246,0.05)',
            }}
          >
            <div className="flex items-center gap-2 mb-3">
              <div
                className="w-6 h-6 rounded-lg flex items-center justify-center"
                style={{ background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)' }}
              >
                <ShieldIcon size={13} className="text-blue-400" />
              </div>
              <h2 className="text-sm font-bold text-blue-300 uppercase tracking-wider">AI Explanation</h2>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              {result.explanation}
            </p>
          </div>

          {/* Confidence bar */}
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-slate-300">AI Detection Confidence</span>
              <span className="text-sm font-bold" style={{ color }}>{result.confidence}%</span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${result.confidence}%`,
                  background: `linear-gradient(90deg, ${color}, ${color}cc)`,
                  boxShadow: `0 0 8px ${color}60`,
                }}
              />
            </div>
            <div className="flex justify-between text-xs text-slate-600 mt-1.5">
              <span>Low</span><span>High</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
