import { useState } from 'react';
import { WifiIcon, ShieldIcon, AlertIcon, XIcon } from '@/components/ui';

interface Network {
  id: string;
  name: string;
  signal: number;
  security: string;
  frequency: string;
  channel: number;
  status: 'available' | 'limited' | 'open';
  signalQuality: 'Excellent' | 'Good' | 'Medium' | 'Weak';
  range: string;
  dBm: string;
}

const MOCK_NETWORKS: Network[] = [
  { id: '1', name: 'Home_WiFi_5G', signal: 5, security: 'WPA3', frequency: '5 GHz', channel: 36, status: 'available', signalQuality: 'Excellent', range: '~10–20 m', dBm: '-42 dBm' },
  { id: '2', name: 'JioFiber_Home', signal: 4, security: 'WPA2', frequency: '2.4 GHz', channel: 6, status: 'available', signalQuality: 'Good', range: '~20–30 m', dBm: '-58 dBm' },
  { id: '3', name: 'BSNL_Broadband', signal: 4, security: 'WPA2', frequency: '5 GHz', channel: 44, status: 'available', signalQuality: 'Good', range: '~25–35 m', dBm: '-61 dBm' },
  { id: '4', name: 'Office_Secure', signal: 3, security: 'WPA2/WPA3', frequency: '5 GHz', channel: 149, status: 'available', signalQuality: 'Medium', range: '~30–40 m', dBm: '-68 dBm' },
  { id: '5', name: 'AndroidHotspot_3F2A', signal: 2, security: 'WPA2', frequency: '2.4 GHz', channel: 11, status: 'available', signalQuality: 'Weak', range: '~40–50 m', dBm: '-77 dBm' },
  { id: '6', name: 'Unknown_Network', signal: 2, security: 'Open', frequency: '2.4 GHz', channel: 1, status: 'open', signalQuality: 'Weak', range: '~40–50 m', dBm: '-79 dBm' },
  { id: '7', name: 'FREE_PUBLIC_WIFI', signal: 3, security: 'Open', frequency: '2.4 GHz', channel: 6, status: 'open', signalQuality: 'Medium', range: '~30–40 m', dBm: '-66 dBm' },
];

function SignalBars({ level, color }: { level: number; color: string }) {
  return (
    <div className="flex items-end gap-0.5 h-4">
      {[1, 2, 3, 4, 5].map(i => (
        <div
          key={i}
          className="w-2 rounded-sm"
          style={{
            height: `${i * 20}%`,
            background: i <= level ? color : 'rgba(255,255,255,0.08)',
            minHeight: 3,
          }}
        />
      ))}
    </div>
  );
}

export default function WiFiScanner() {
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);
  const [selected, setSelected] = useState<Network | null>(null);

  function handleScan() {
    setScanning(true);
    setScanned(false);
    setTimeout(() => { setScanning(false); setScanned(true); }, 2500);
  }

  function getSignalColor(q: Network['signalQuality']) {
    if (q === 'Excellent') return '#22c55e';
    if (q === 'Good') return '#3b82f6';
    if (q === 'Medium') return '#f97316';
    return '#ef4444';
  }

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in-up">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)' }}
          >
            <WifiIcon size={20} className="text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">Wi-Fi Scanner</h1>
            <p className="text-sm text-slate-400">View nearby wireless networks and estimated signal strength.</p>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div
        className="rounded-xl p-4 mb-6 flex items-start gap-3"
        style={{ background: 'rgba(59,130,246,0.06)', border: '1px solid rgba(59,130,246,0.15)' }}
      >
        <ShieldIcon size={16} className="text-blue-400 mt-0.5 flex-shrink-0" />
        <p className="text-sm text-slate-400">
          <span className="text-blue-300 font-medium">Read-only mode. </span>
          This scanner only displays publicly visible network information. No passwords, packet injection, deauthentication, or unauthorized access is performed. Estimated ranges are approximate indicators only.
        </p>
      </div>

      {/* Scan button */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={handleScan}
          disabled={scanning}
          className="btn-primary flex items-center gap-2"
          style={{ paddingLeft: 24, paddingRight: 24, paddingTop: 12, paddingBottom: 12 }}
        >
          {scanning ? (
            <>
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Scanning...
            </>
          ) : (
            <>
              <WifiIcon size={16} />
              SCAN NEARBY NETWORKS
            </>
          )}
        </button>
        {scanned && (
          <span className="text-sm text-slate-400">{MOCK_NETWORKS.length} networks found</span>
        )}
      </div>

      <div className="flex gap-5">
        {/* Networks table */}
        <div
          className={`rounded-2xl overflow-hidden flex-1 transition-all ${!scanned && !scanning ? 'opacity-40 pointer-events-none' : ''}`}
          style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          {scanning ? (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="relative w-16 h-16">
                <div
                  className="absolute inset-0 rounded-full animate-ping"
                  style={{ background: 'rgba(59,130,246,0.2)', border: '2px solid rgba(59,130,246,0.4)' }}
                />
                <div
                  className="absolute inset-2 rounded-full animate-spin-slow"
                  style={{ border: '2px solid transparent', borderTop: '2px solid #3b82f6' }}
                />
                <div className="absolute inset-4 rounded-full flex items-center justify-center">
                  <WifiIcon size={16} className="text-blue-400" />
                </div>
              </div>
              <div className="text-center">
                <p className="text-white font-semibold mb-1">Scanning nearby networks...</p>
                <p className="text-sm text-slate-400">Please wait while we detect wireless signals</p>
              </div>
            </div>
          ) : (
            <>
              <div className="px-6 py-4 border-b" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                <h2 className="text-sm font-bold text-white">Nearby Wi-Fi Networks</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      {['Network Name', 'Signal', 'Est. Range *', 'Security', 'Frequency', 'Status'].map(h => (
                        <th key={h} className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {scanned && MOCK_NETWORKS.map((net, i) => {
                      const color = getSignalColor(net.signalQuality);
                      const isOpen = net.security === 'Open';
                      return (
                        <tr
                          key={net.id}
                          onClick={() => setSelected(net)}
                          className="cursor-pointer hover:bg-white/[0.02] transition-colors"
                          style={{
                            borderBottom: i < MOCK_NETWORKS.length - 1 ? '1px solid rgba(255,255,255,0.03)' : 'none',
                            background: selected?.id === net.id ? 'rgba(59,130,246,0.06)' : 'transparent',
                          }}
                        >
                          <td className="px-6 py-3.5">
                            <div className="flex items-center gap-2">
                              <WifiIcon size={14} className="text-slate-500" />
                              <span className="text-sm text-slate-200 font-medium">{net.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-3.5">
                            <div className="flex items-center gap-2">
                              <SignalBars level={net.signal} color={color} />
                              <span className="text-xs" style={{ color }}>{net.signalQuality}</span>
                            </div>
                          </td>
                          <td className="px-6 py-3.5 text-sm text-slate-400">{net.range}</td>
                          <td className="px-6 py-3.5">
                            <span
                              className="text-xs font-medium px-2 py-0.5 rounded-full"
                              style={{
                                background: isOpen ? 'rgba(239,68,68,0.1)' : 'rgba(34,197,94,0.08)',
                                color: isOpen ? '#f87171' : '#86efac',
                                border: `1px solid ${isOpen ? 'rgba(239,68,68,0.25)' : 'rgba(34,197,94,0.2)'}`,
                              }}
                            >
                              {net.security}
                            </span>
                          </td>
                          <td className="px-6 py-3.5 text-sm text-slate-400">{net.frequency}</td>
                          <td className="px-6 py-3.5">
                            <div className="flex items-center gap-1.5">
                              {isOpen ? (
                                <>
                                  <AlertIcon size={13} className="text-orange-400" />
                                  <span className="text-xs text-orange-400">Unsecured</span>
                                </>
                              ) : (
                                <>
                                  <ShieldIcon size={13} className="text-green-400" />
                                  <span className="text-xs text-green-400">Available</span>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {scanned && (
                <p className="px-6 py-3 text-xs text-slate-600 border-t" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
                  * Estimated Range is an approximate indicator based on signal strength and is not an exact physical measurement.
                </p>
              )}
            </>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <div
            className="w-72 rounded-2xl p-5 flex-shrink-0 fade-in-up"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white">Network Details</h3>
              <button onClick={() => setSelected(null)} className="text-slate-500 hover:text-slate-300 transition-colors">
                <XIcon size={16} />
              </button>
            </div>

            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
              style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)' }}
            >
              <WifiIcon size={22} className="text-blue-400" />
            </div>

            <div className="flex flex-col gap-3">
              {[
                { label: 'Network Name', value: selected.name },
                { label: 'Signal Strength', value: selected.dBm },
                { label: 'Signal Quality', value: selected.signalQuality },
                { label: 'Estimated Range', value: selected.range + ' *' },
                { label: 'Security', value: selected.security },
                { label: 'Frequency', value: selected.frequency },
                { label: 'Channel', value: String(selected.channel) },
                { label: 'Status', value: selected.security === 'Open' ? '⚠ Unsecured' : 'Available' },
              ].map(({ label, value }) => (
                <div key={label} className="flex flex-col gap-0.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', paddingBottom: 10 }}>
                  <p className="text-xs text-slate-500">{label}</p>
                  <p className="text-sm text-slate-200 font-medium">{value}</p>
                </div>
              ))}
            </div>

            {selected.security === 'Open' && (
              <div
                className="mt-4 p-3 rounded-xl"
                style={{ background: 'rgba(249,115,22,0.08)', border: '1px solid rgba(249,115,22,0.2)' }}
              >
                <p className="text-xs text-orange-300 font-medium mb-1">⚠ Unsecured Network</p>
                <p className="text-xs text-orange-400/70">This network has no encryption. Avoid transmitting sensitive information over open Wi-Fi.</p>
              </div>
            )}

            <p className="text-xs text-slate-600 mt-4">* Range is an estimate only and not a precise measurement.</p>
          </div>
        )}
      </div>
    </div>
  );
}
