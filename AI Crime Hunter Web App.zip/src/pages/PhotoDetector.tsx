import { useState } from 'react';
import { useNav } from '@/context/NavContext';
import { CameraIcon, UploadIcon, ScanIcon, WorkflowSteps } from '@/components/ui';

const WORKFLOW = [
  { label: 'Photo Input', state: 'done' as const },
  { label: 'Image Processing', state: 'active' as const },
  { label: 'OCR / Text Extraction', state: 'pending' as const },
  { label: 'Visual Analysis', state: 'pending' as const },
  { label: 'QR / Link Detection', state: 'pending' as const },
  { label: 'AI Analysis', state: 'pending' as const },
  { label: 'Risk Score', state: 'pending' as const },
  { label: 'Final Result', state: 'pending' as const },
];

export default function PhotoDetector() {
  const { startScan } = useNav();
  const [dragging, setDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState('');

  function handleFile(file: File) {
    setFileName(file.name);
    const url = URL.createObjectURL(file);
    setPreview(url);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }

  function handleInput(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in-up">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)' }}
          >
            <CameraIcon size={20} className="text-purple-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">AI Photo Detector</h1>
            <p className="text-sm text-slate-400">Upload an image or screenshot and let AI analyze suspicious content.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload area */}
        <div className="lg:col-span-2 flex flex-col gap-5">
          <div
            className="rounded-2xl p-6"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <label
              htmlFor="photo-upload"
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              className="block cursor-pointer"
            >
              {preview ? (
                <div className="rounded-xl overflow-hidden relative" style={{ minHeight: 260 }}>
                  <img
                    src={preview}
                    alt="Uploaded"
                    className="w-full object-contain rounded-xl"
                    style={{ maxHeight: 320 }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-xl flex items-end p-4">
                    <p className="text-white text-sm font-medium">{fileName}</p>
                  </div>
                </div>
              ) : (
                <div
                  className="rounded-xl flex flex-col items-center justify-center gap-4 py-16 transition-all"
                  style={{
                    border: `2px dashed ${dragging ? 'rgba(139,92,246,0.6)' : 'rgba(255,255,255,0.1)'}`,
                    background: dragging ? 'rgba(139,92,246,0.05)' : 'rgba(8,14,29,0.4)',
                  }}
                >
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center"
                    style={{ background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.2)' }}
                  >
                    <CameraIcon size={30} className="text-purple-400" />
                  </div>
                  <div className="text-center">
                    <p className="text-base font-semibold text-slate-300 mb-1">Drag & Drop Image Here</p>
                    <p className="text-sm text-slate-500">or click to browse files</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    {['JPG', 'PNG', 'WEBP', 'GIF'].map(f => (
                      <span key={f} className="px-2 py-0.5 rounded" style={{ background: 'rgba(255,255,255,0.05)' }}>{f}</span>
                    ))}
                  </div>
                </div>
              )}
              <input id="photo-upload" type="file" accept="image/*" className="hidden" onChange={handleInput} />
            </label>
          </div>

          {/* Preview actions */}
          {preview && (
            <div className="flex gap-3">
              <button
                onClick={() => { setPreview(null); setFileName(''); }}
                className="btn-outline text-sm flex-1"
              >
                Remove &amp; Choose Another
              </button>
            </div>
          )}

          <button
            onClick={() => startScan('photo')}
            className="btn-primary w-full flex items-center justify-center gap-2"
            style={{ paddingTop: 15, paddingBottom: 15, borderRadius: 14, fontSize: 15 }}
          >
            <ScanIcon size={18} />
            ANALYZE PHOTO
          </button>
        </div>

        {/* Workflow + tips */}
        <div className="flex flex-col gap-5">
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <h3 className="text-sm font-semibold text-slate-300 mb-4 uppercase tracking-wider">Analysis Workflow</h3>
            <WorkflowSteps steps={WORKFLOW} />
          </div>

          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(139,92,246,0.05)', border: '1px solid rgba(139,92,246,0.15)' }}
          >
            <h3 className="text-sm font-semibold text-purple-300 mb-3">What we check</h3>
            <ul className="flex flex-col gap-2">
              {[
                'Embedded text via OCR',
                'QR code & barcode scanning',
                'Suspicious branding/logos',
                'Fake website screenshots',
                'Sensitive information visible',
                'Image metadata analysis',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-1 h-1 rounded-full bg-purple-400 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
