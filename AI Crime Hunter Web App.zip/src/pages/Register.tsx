import { useState } from 'react';
import Logo from '@/components/Logo';
import { MailIcon, LockIcon, UserIcon, ArrowRightIcon } from '@/components/ui';
import { useNav } from '@/context/NavContext';

export default function Register() {
  const { login, navigate } = useNav();
  const [loading, setLoading] = useState(false);

  function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); login(); }, 1200);
  }

  return (
    <div
      className="min-h-full flex items-center justify-center px-8 py-12"
      style={{ background: 'linear-gradient(160deg, #060b18 0%, #080e1d 100%)' }}
    >
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Logo size="md" />
        </div>

        <div
          className="rounded-2xl p-8"
          style={{ background: 'rgba(14,22,45,0.8)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <div className="mb-6">
            <h1 className="text-xl font-bold text-white mb-1">Create your account</h1>
            <p className="text-slate-400 text-sm">Start detecting cyber threats with AI.</p>
          </div>

          <form onSubmit={handleRegister} className="flex flex-col gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1.5">Full name</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <UserIcon size={16} />
                </div>
                <input type="text" className="input-field pl-9" placeholder="Your name" required />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1.5">Email address</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <MailIcon size={16} />
                </div>
                <input type="email" className="input-field pl-9" placeholder="you@example.com" required />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <LockIcon size={16} />
                </div>
                <input type="password" className="input-field pl-9" placeholder="Create a password" required />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1.5">Confirm password</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <LockIcon size={16} />
                </div>
                <input type="password" className="input-field pl-9" placeholder="Repeat your password" required />
              </div>
            </div>

            <label className="flex items-start gap-2 cursor-pointer mt-1">
              <input type="checkbox" className="w-4 h-4 mt-0.5 rounded accent-blue-500" required />
              <span className="text-sm text-slate-400">
                I agree to the{' '}
                <span className="text-blue-400">Terms of Service</span>
                {' '}and{' '}
                <span className="text-blue-400">Privacy Policy</span>
              </span>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center justify-center gap-2 mt-2"
              style={{ paddingTop: 14, paddingBottom: 14, borderRadius: 12 }}
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Creating account...
                </>
              ) : (
                <>
                  CREATE ACCOUNT
                  <ArrowRightIcon size={16} />
                </>
              )}
            </button>

            <p className="text-center text-sm text-slate-500">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => navigate('login')}
                className="text-blue-400 hover:text-blue-300 font-medium transition-colors"
              >
                Sign in
              </button>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
