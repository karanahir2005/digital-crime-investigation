import { useState } from 'react';
import Logo from '@/components/Logo';
import { MailIcon, LockIcon, ShieldIcon, ArrowRightIcon } from '@/components/ui';
import { useNav } from '@/context/NavContext';

export default function Login() {
  const { login, navigate } = useNav();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);

  function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      login();
    }, 1200);
  }

  return (
    <div
      className="min-h-full flex"
      style={{ background: 'linear-gradient(160deg, #060b18 0%, #080e1d 60%, #06111e 100%)' }}
    >
      {/* Left panel */}
      <div
        className="hidden lg:flex flex-col w-5/12 p-12 relative overflow-hidden"
        style={{ background: 'linear-gradient(160deg, #060c1c 0%, #04091a 100%)', borderRight: '1px solid rgba(255,255,255,0.04)' }}
      >
        {/* Background circuit decoration */}
        <svg
          className="absolute inset-0 w-full h-full opacity-10 pointer-events-none"
          viewBox="0 0 400 800"
          preserveAspectRatio="xMidYMid slice"
        >
          <g stroke="#3b82f6" strokeWidth="0.8" fill="none">
            <line x1="50" y1="0" x2="50" y2="200" />
            <line x1="50" y1="200" x2="120" y2="200" />
            <line x1="120" y1="200" x2="120" y2="300" />
            <line x1="350" y1="100" x2="350" y2="400" />
            <line x1="200" y1="100" x2="350" y2="100" />
            <line x1="200" y1="600" x2="200" y2="800" />
            <line x1="80" y1="600" x2="200" y2="600" />
            <line x1="80" y1="500" x2="80" y2="600" />
            <line x1="280" y1="400" x2="350" y2="400" />
            <line x1="280" y1="350" x2="280" y2="450" />
            <circle cx="50" cy="200" r="3" fill="#3b82f6" opacity="0.6" />
            <circle cx="120" cy="300" r="3" fill="#06b6d4" opacity="0.6" />
            <circle cx="350" cy="100" r="3" fill="#3b82f6" opacity="0.6" />
            <circle cx="200" cy="600" r="3" fill="#06b6d4" opacity="0.6" />
            <circle cx="280" cy="400" r="4" fill="#3b82f6" opacity="0.8" />
          </g>
        </svg>

        {/* Logo */}
        <div className="relative z-10">
          <Logo size="lg" />
        </div>

        {/* Spacer */}
        <div className="flex-1 flex flex-col items-start justify-center relative z-10 mt-12">
          {/* Glowing emblem */}
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center mb-8"
            style={{
              background: 'linear-gradient(135deg, rgba(59,130,246,0.15), rgba(6,182,212,0.08))',
              border: '1px solid rgba(59,130,246,0.25)',
              boxShadow: '0 0 40px rgba(59,130,246,0.1)',
            }}
          >
            <ShieldIcon size={36} className="text-blue-400" />
          </div>

          <h2 className="text-3xl font-bold text-white mb-4" style={{ lineHeight: 1.2 }}>
            AI-Powered Cyber<br />Threat Detection
          </h2>
          <p className="text-slate-400 text-base leading-relaxed max-w-xs">
            Instantly analyze emails, photos, and SMS messages for phishing, scams, and digital threats.
          </p>

          <div className="mt-8 flex flex-col gap-3">
            {[
              { icon: '✦', text: 'AI threat analysis in seconds' },
              { icon: '✦', text: 'Clear risk scores & explanations' },
              { icon: '✦', text: 'Email, photo, and SMS detection' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-3 text-sm">
                <span className="text-cyan-400">{f.icon}</span>
                <span className="text-slate-300">{f.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom badge */}
        <div className="relative z-10 mt-auto">
          <div
            className="inline-flex items-center gap-2 px-3 py-2 rounded-full text-xs text-slate-400"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            AI System Online &middot; All systems operational
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        {/* Logo on mobile */}
        <div className="lg:hidden mb-8">
          <Logo size="md" />
        </div>

        <div className="w-full max-w-md">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-white mb-2">Welcome back</h1>
            <p className="text-slate-400">Protect yourself with AI-powered cyber threat detection.</p>
          </div>

          <form onSubmit={handleLogin} className="flex flex-col gap-5">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Email address</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <MailIcon size={16} />
                </div>
                <input
                  type="email"
                  className="input-field pl-9"
                  placeholder="you@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Password</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <LockIcon size={16} />
                </div>
                <input
                  type="password"
                  className="input-field pl-9"
                  placeholder="Enter your password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Remember + Forgot */}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={e => setRemember(e.target.checked)}
                  className="w-4 h-4 rounded accent-blue-500"
                />
                <span className="text-sm text-slate-400">Remember me</span>
              </label>
              <button type="button" className="text-sm text-blue-400 hover:text-blue-300 transition-colors">
                Forgot password?
              </button>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center justify-center gap-2 mt-1"
              style={{ paddingTop: 14, paddingBottom: 14, borderRadius: 12 }}
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in...
                </>
              ) : (
                <>
                  LOGIN
                  <ArrowRightIcon size={16} />
                </>
              )}
            </button>

            {/* Register */}
            <p className="text-center text-sm text-slate-500">
              {"Don't have an account? "}
              <button
                type="button"
                onClick={() => navigate('register')}
                className="text-blue-400 hover:text-blue-300 font-medium transition-colors"
              >
                Create Account
              </button>
            </p>
          </form>

          {/* Demo hint */}
          <div
            className="mt-6 px-4 py-3 rounded-xl text-xs text-slate-500 text-center"
            style={{ background: 'rgba(59,130,246,0.04)', border: '1px solid rgba(59,130,246,0.1)' }}
          >
            Demo: enter any email and password to log in
          </div>
        </div>
      </div>
    </div>
  );
}
