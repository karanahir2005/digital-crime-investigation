import { useEffect, useState } from 'react';
import { useNav, type ScanResult } from '@/context/NavContext';
import { CheckIcon, ShieldIcon } from '@/components/ui';

const STEPS_BY_TYPE = {
  email: [
    'Input received',
    'Extracting email metadata',
    'Checking sender & headers',
    'Scanning URLs & domains',
    'AI content analysis',
    'Calculating risk score',
    'Generating explanation',
  ],
  photo: [
    'Input received',
    'Processing image',
    'Running OCR text extraction',
    'Visual content analysis',
    'Scanning QR codes & links',
    'AI threat analysis',
    'Calculating risk score',
  ],
  sms: [
    'Input received',
    'Extracting SMS data',
    'Checking sender number',
    'Analyzing URLs & links',
    'Scam pattern detection',
    'AI threat analysis',
    'Calculating risk score',
  ],
};

const MOCK_RESULTS: Record<string, Omit<ScanResult, 'id' | 'timestamp'>> = {
  email: {
    type: 'email',
    target: 'support@paypa1-secure.com',
    score: 91,
    verdict: 'high-risk',
    confidence: 96,
    threatType: 'Phishing Email',
    indicators: ['Suspicious sender domain', 'Reply-To address mismatch', 'Urgent language detected', 'Malicious URL embedded', 'Credential request detected'],
    explanation: "Multiple phishing indicators were detected in this email. The sender domain appears inconsistent with the claimed organization and the message attempts to create urgency while requesting sensitive information.",
    recommendation: "Do not open links, download attachments or provide personal information.",
  },
  photo: {
    type: 'photo',
    target: 'uploaded_image.png',
    score: 72,
    verdict: 'suspicious',
    confidence: 89,
    threatType: 'Suspicious Image Content',
    indicators: ['Suspicious QR code detected', 'Potential phishing page visible', 'Suspicious branding elements', 'Sensitive information visible'],
    explanation: "The image contains elements commonly found in phishing attempts, including a suspicious QR code and branding that mimics a legitimate organization.",
    recommendation: "Do not interact with links or provide sensitive information until verified.",
  },
  sms: {
    type: 'sms',
    target: 'Unknown Sender',
    score: 87,
    verdict: 'high-risk',
    confidence: 94,
    threatType: 'SMS Phishing Scam',
    indicators: ['Suspicious link detected', 'Urgency language detected', 'Prize/reward claim present', 'Request for personal information', 'Suspicious sender number'],
    explanation: "This message contains multiple indicators commonly associated with phishing or scam campaigns including urgency triggers and suspicious links.",
    recommendation: "Do not open links, download attachments or provide personal information.",
  },
};

export default function AIProcessing() {
  const { processingType, navigate, setCurrentResult, addToHistory } = useNav();
  const type = processingType ?? 'email';
  const steps = STEPS_BY_TYPE[type];

  const [currentStep, setCurrentStep] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setCurrentStep(i);
      if (i >= steps.length) {
        clearInterval(interval);
        setTimeout(() => setDone(true), 600);
      }
    }, 600);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!done) return;
    const result: ScanResult = {
      ...MOCK_RESULTS[type],
      id: Date.now().toString(),
      timestamp: new Date(),
    };
    setCurrentResult(result);
    addToHistory(result);
    const t = setTimeout(() => navigate('result'), 1000);
    return () => clearTimeout(t);
  }, [done]);

  const typeLabel = type === 'email' ? 'EMAIL' : type === 'photo' ? 'PHOTO' : 'SMS';
  const typeColor = type === 'email' ? '#3b82f6' : type === 'photo' ? '#8b5cf6' : '#06b6d4';

  return (
    <div
      className="min-h-full flex flex-col items-center justify-center p-8"
      style={{ background: 'linear-gradient(160deg, #060b18 0%, #080e1d 100%)' }}
    >
      <div className="w-full max-w-md text-center fade-in-up">
        {/* Animated AI orb */}
        <div className="flex justify-center mb-8 relative">
          <div className="relative w-24 h-24">
            <div
              className="absolute inset-0 rounded-full pulse-ring"
              style={{ background: `${typeColor}10`, border: `1px solid ${typeColor}30` }}
            />
            <div
              className="absolute inset-2 rounded-full animate-spin-slow"
              style={{ border: `2px solid transparent`, borderTop: `2px solid ${typeColor}`, borderRight: `1px solid ${typeColor}40` }}
            />
            <div
              className="absolute inset-4 rounded-full flex items-center justify-center"
              style={{ background: `${typeColor}18`, border: `1px solid ${typeColor}30` }}
            >
              <span style={{ color: typeColor }}><ShieldIcon size={22} /></span>
            </div>
          </div>
        </div>

        {/* Title */}
        {!done ? (
          <>
            <div
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold mb-4"
              style={{ background: `${typeColor}12`, border: `1px solid ${typeColor}25`, color: typeColor }}
            >
              {typeLabel} ANALYSIS
            </div>
            <h1 className="text-2xl font-black text-white mb-2">AI IS ANALYZING...</h1>
            <p className="text-slate-400 mb-8">Please wait while AI checks your content.</p>
          </>
        ) : (
          <>
            <div
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold mb-4"
              style={{ background: 'rgba(34,197,94,0.12)', border: '1px solid rgba(34,197,94,0.25)', color: '#22c55e' }}
            >
              <CheckIcon size={10} />
              COMPLETE
            </div>
            <h1 className="text-2xl font-black text-white mb-2">ANALYSIS COMPLETE</h1>
            <p className="text-slate-400 mb-8">Redirecting to your results...</p>
          </>
        )}

        {/* Steps */}
        <div
          className="rounded-2xl p-6 text-left"
          style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <div className="flex flex-col gap-3">
            {steps.map((step, i) => {
              const isComplete = i < currentStep;
              const isActive = i === currentStep && !done;
              const isPending = i > currentStep;

              return (
                <div key={i} className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                      isComplete ? 'step-complete' : ''
                    }`}
                    style={{
                      background: isComplete
                        ? 'rgba(59,130,246,0.25)'
                        : isActive
                        ? `${typeColor}25`
                        : 'rgba(255,255,255,0.04)',
                      border: isComplete
                        ? '1px solid rgba(59,130,246,0.5)'
                        : isActive
                        ? `1px solid ${typeColor}60`
                        : '1px solid rgba(255,255,255,0.06)',
                    }}
                  >
                    {isComplete && <CheckIcon size={12} className="text-blue-400" />}
                    {isActive && (
                      <span
                        className="w-2.5 h-2.5 rounded-full animate-pulse"
                        style={{ background: typeColor }}
                      />
                    )}
                    {isPending && (
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                    )}
                  </div>
                  <span
                    className={`text-sm transition-colors ${
                      isComplete ? 'text-blue-300' :
                      isActive ? 'font-medium' :
                      'text-slate-600'
                    }`}
                    style={isActive ? { color: typeColor } : {}}
                  >
                    {step}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Progress bar */}
          <div className="mt-5 h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${(currentStep / steps.length) * 100}%`,
                background: `linear-gradient(90deg, ${typeColor}, ${typeColor}aa)`,
              }}
            />
          </div>
          <p className="text-xs text-slate-600 text-right mt-1">
            {Math.round((currentStep / steps.length) * 100)}% complete
          </p>
        </div>
      </div>
    </div>
  );
}
