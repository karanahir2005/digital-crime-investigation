import { useState } from 'react';
import { useNav } from '@/context/NavContext';
import { UserIcon, MailIcon, ShieldIcon, ScanIcon, CheckIcon } from '@/components/ui';

export default function Profile() {
  const { user, history } = useNav();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [saved, setSaved] = useState(false);

  const safe = history.filter(s => s.verdict === 'safe').length;
  const highRisk = history.filter(s => s.verdict === 'high-risk').length;

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    setEditing(false);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="p-8 max-w-4xl mx-auto fade-in-up">
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white mb-1">Profile</h1>
        <p className="text-sm text-slate-400">Manage your account information.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User card */}
        <div
          className="rounded-2xl p-6 flex flex-col items-center text-center"
          style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center text-2xl font-black text-white mb-4"
            style={{ background: 'linear-gradient(135deg, #3b82f6, #06b6d4)' }}
          >
            {user.name.charAt(0)}
          </div>
          <h2 className="text-lg font-bold text-white mb-1">{user.name}</h2>
          <p className="text-sm text-slate-400 mb-1">{user.role}</p>
          <p className="text-xs text-slate-600">Member since {user.joinDate}</p>

          <div
            className="w-full mt-5 p-3 rounded-xl"
            style={{ background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.2)' }}
          >
            <p className="text-xs text-green-400 font-medium">Account Active</p>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-col gap-4">
          {[
            { label: 'Total Scans', value: history.length, icon: <ScanIcon size={18} />, color: '#3b82f6' },
            { label: 'Safe Results', value: safe, icon: <CheckIcon size={18} />, color: '#22c55e' },
            { label: 'Threats Found', value: highRisk, icon: <ShieldIcon size={18} />, color: '#ef4444' },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="rounded-2xl p-5 flex items-center gap-4" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
                <span style={{ color }}>{icon}</span>
              </div>
              <div>
                <p className="text-xl font-bold text-white">{value}</p>
                <p className="text-xs text-slate-500">{label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Edit form */}
        <div className="rounded-2xl p-6" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-sm font-bold text-white">Account Details</h3>
            {!editing && (
              <button onClick={() => setEditing(true)} className="text-xs text-blue-400 hover:text-blue-300 transition-colors">
                Edit
              </button>
            )}
          </div>

          {saved && (
            <div className="flex items-center gap-2 mb-4 p-3 rounded-xl" style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}>
              <CheckIcon size={14} className="text-green-400" />
              <span className="text-xs text-green-400">Profile saved successfully</span>
            </div>
          )}

          <form onSubmit={handleSave} className="flex flex-col gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Full Name</label>
              {editing ? (
                <input type="text" className="input-field text-sm" value={name} onChange={e => setName(e.target.value)} />
              ) : (
                <p className="text-sm text-slate-200 py-2">{user.name}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Email</label>
              {editing ? (
                <input type="email" className="input-field text-sm" defaultValue={user.email} />
              ) : (
                <p className="text-sm text-slate-200 py-2">{user.email}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Role</label>
              <p className="text-sm text-slate-200 py-2">{user.role}</p>
            </div>

            {editing && (
              <div className="flex gap-2 mt-2">
                <button type="submit" className="btn-primary text-sm flex-1">Save Changes</button>
                <button type="button" onClick={() => setEditing(false)} className="btn-outline text-sm">Cancel</button>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
