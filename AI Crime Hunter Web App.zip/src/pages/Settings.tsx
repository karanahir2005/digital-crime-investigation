import { useState } from 'react';
import { SettingsIcon, BellIcon, ShieldIcon, UserIcon, ZapIcon } from '@/components/ui';

interface ToggleProps { value: boolean; onChange: (v: boolean) => void; color?: string; }
function Toggle({ value, onChange, color = '#3b82f6' }: ToggleProps) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="relative flex-shrink-0 transition-all"
      style={{
        width: 44,
        height: 24,
        borderRadius: 12,
        background: value ? color : 'rgba(255,255,255,0.08)',
        border: `1px solid ${value ? color + '60' : 'rgba(255,255,255,0.1)'}`,
        transition: 'all 0.2s',
      }}
    >
      <span
        className="absolute top-0.5 transition-all"
        style={{
          width: 20,
          height: 20,
          borderRadius: 10,
          background: value ? 'white' : 'rgba(255,255,255,0.3)',
          left: value ? 'calc(100% - 22px)' : 2,
          transition: 'all 0.2s',
        }}
      />
    </button>
  );
}

interface SettingRowProps { label: string; desc?: string; value: boolean; onChange: (v: boolean) => void; color?: string; }
function SettingRow({ label, desc, value, onChange, color }: SettingRowProps) {
  return (
    <div className="flex items-center justify-between py-3.5 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="mr-4">
        <p className="text-sm font-medium text-slate-200">{label}</p>
        {desc && <p className="text-xs text-slate-500 mt-0.5">{desc}</p>}
      </div>
      <Toggle value={value} onChange={onChange} color={color} />
    </div>
  );
}

export default function Settings() {
  const [notifs, setNotifs] = useState({
    highRisk: true, suspicious: true, safe: false, weekly: true, email: true,
  });
  const [privacy, setPrivacy] = useState({
    saveHistory: true, analytics: true, autoDelete: false,
  });
  const [ai, setAI] = useState({
    deepScan: true, autoAnalyze: false, confidence: true,
  });

  const Section = ({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) => (
    <div className="rounded-2xl overflow-hidden mb-5" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="px-6 py-4 flex items-center gap-3 border-b" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
        <span className="text-blue-400">{icon}</span>
        <h3 className="text-sm font-bold text-white">{title}</h3>
      </div>
      <div className="px-6 pb-2">{children}</div>
    </div>
  );

  return (
    <div className="p-8 max-w-3xl mx-auto fade-in-up">
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white mb-1">Settings</h1>
        <p className="text-sm text-slate-400">Configure your AI Crime Hunter preferences.</p>
      </div>

      <Section title="Notifications" icon={<BellIcon size={18} />}>
        <SettingRow label="High Risk Alerts" desc="Notify when a scan is marked High Risk" value={notifs.highRisk} onChange={v => setNotifs(n => ({ ...n, highRisk: v }))} color="#ef4444" />
        <SettingRow label="Suspicious Alerts" desc="Notify when a scan is Suspicious" value={notifs.suspicious} onChange={v => setNotifs(n => ({ ...n, suspicious: v }))} color="#f97316" />
        <SettingRow label="Safe Confirmations" desc="Notify when a scan is confirmed Safe" value={notifs.safe} onChange={v => setNotifs(n => ({ ...n, safe: v }))} color="#22c55e" />
        <SettingRow label="Weekly Summary" desc="Receive a weekly digest of scan activity" value={notifs.weekly} onChange={v => setNotifs(n => ({ ...n, weekly: v }))} />
        <SettingRow label="Email Notifications" desc="Send notifications to your email address" value={notifs.email} onChange={v => setNotifs(n => ({ ...n, email: v }))} />
      </Section>

      <Section title="Privacy & Data" icon={<ShieldIcon size={18} />}>
        <SettingRow label="Save Scan History" desc="Keep a record of all analyzed content" value={privacy.saveHistory} onChange={v => setPrivacy(p => ({ ...p, saveHistory: v }))} />
        <SettingRow label="Usage Analytics" desc="Help improve the AI by sharing anonymized data" value={privacy.analytics} onChange={v => setPrivacy(p => ({ ...p, analytics: v }))} />
        <SettingRow label="Auto-Delete History" desc="Automatically delete scans older than 30 days" value={privacy.autoDelete} onChange={v => setPrivacy(p => ({ ...p, autoDelete: v }))} color="#f97316" />
      </Section>

      <Section title="AI Configuration" icon={<ZapIcon size={18} />}>
        <SettingRow label="Deep Scan Mode" desc="Run thorough analysis (slightly slower)" value={ai.deepScan} onChange={v => setAI(a => ({ ...a, deepScan: v }))} />
        <SettingRow label="Auto-Analyze Clipboard" desc="Automatically check clipboard content" value={ai.autoAnalyze} onChange={v => setAI(a => ({ ...a, autoAnalyze: v }))} />
        <SettingRow label="Show Confidence Scores" desc="Display AI confidence percentage on results" value={ai.confidence} onChange={v => setAI(a => ({ ...a, confidence: v }))} />
      </Section>

      {/* Account actions */}
      <div className="rounded-2xl p-6" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
          <UserIcon size={18} className="text-blue-400" />
          Account Actions
        </h3>
        <div className="flex flex-wrap gap-3">
          <button className="btn-outline text-sm">Export Data</button>
          <button className="btn-outline text-sm">Clear History</button>
          <button
            className="text-sm px-4 py-2 rounded-lg font-medium transition-all"
            style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', color: '#f87171' }}
          >
            Delete Account
          </button>
        </div>
      </div>
    </div>
  );
}
