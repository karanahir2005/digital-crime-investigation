import { useState } from 'react';
import { useNav, formatDate, type ScanResult, type Page } from '@/context/NavContext';
import { StatusBadge, MailIcon, CameraIcon, MessageIcon, FilterIcon, EyeIcon, HistoryIcon } from '@/components/ui';

type TypeFilter  = 'all' | 'email' | 'photo' | 'sms';
type RiskFilter  = 'all' | 'safe' | 'suspicious' | 'high-risk';

export default function ScanHistory() {
  const { history, navigate, setCurrentResult } = useNav();
  const [typeFilter,  setTypeFilter]  = useState<TypeFilter>('all');
  const [riskFilter,  setRiskFilter]  = useState<RiskFilter>('all');
  const [search, setSearch] = useState('');

  const filtered = history.filter(s => {
    if (typeFilter !== 'all' && s.type !== typeFilter) return false;
    if (riskFilter !== 'all' && s.verdict !== riskFilter) return false;
    if (search && !s.target.toLowerCase().includes(search.toLowerCase()) && !s.threatType.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  function viewResult(r: ScanResult) {
    setCurrentResult(r);
    navigate('result');
  }

  const typeBtn = (label: string, val: TypeFilter) => (
    <button
      key={val}
      onClick={() => setTypeFilter(val)}
      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
      style={{
        background: typeFilter === val ? 'rgba(59,130,246,0.2)' : 'rgba(255,255,255,0.04)',
        color: typeFilter === val ? '#93c5fd' : '#64748b',
        border: `1px solid ${typeFilter === val ? 'rgba(59,130,246,0.4)' : 'rgba(255,255,255,0.06)'}`,
      }}
    >{label}</button>
  );

  const riskBtn = (label: string, val: RiskFilter, color: string) => (
    <button
      key={val}
      onClick={() => setRiskFilter(val)}
      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
      style={{
        background: riskFilter === val ? `${color}18` : 'rgba(255,255,255,0.04)',
        color: riskFilter === val ? color : '#64748b',
        border: `1px solid ${riskFilter === val ? `${color}40` : 'rgba(255,255,255,0.06)'}`,
      }}
    >{label}</button>
  );

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in-up">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)' }}>
            <HistoryIcon size={20} className="text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">Scan History</h1>
            <p className="text-sm text-slate-400">{history.length} total scans recorded</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div
        className="rounded-2xl p-5 mb-6"
        style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
      >
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-1 flex-wrap">
            <FilterIcon size={14} className="text-slate-500 mr-1" />
            {typeBtn('All', 'all')}
            {typeBtn('Email', 'email')}
            {typeBtn('Photo', 'photo')}
            {typeBtn('SMS', 'sms')}
          </div>

          <div className="w-px h-6 bg-white/10 hidden sm:block" />

          <div className="flex items-center gap-1 flex-wrap">
            {riskBtn('Safe', 'safe', '#22c55e')}
            {riskBtn('Suspicious', 'suspicious', '#f97316')}
            {riskBtn('High Risk', 'high-risk', '#ef4444')}
          </div>

          <div className="ml-auto">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search..."
              className="input-field text-sm"
              style={{ width: 200 }}
            />
          </div>
        </div>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div
          className="rounded-2xl flex flex-col items-center justify-center py-20 gap-3"
          style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <HistoryIcon size={40} className="text-slate-700" />
          <p className="text-slate-400 font-medium">No scans match your filters</p>
          <p className="text-sm text-slate-600">Try adjusting the filters above</p>
        </div>
      ) : (
        <div
          className="rounded-2xl overflow-hidden"
          style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <div className="px-6 py-3.5 border-b flex items-center justify-between" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
            <span className="text-sm text-slate-400">{filtered.length} results</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  {['Scan ID', 'Type', 'Target', 'Risk Score', 'Result', 'Date', 'Action'].map(h => (
                    <th key={h} className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s, i) => (
                  <tr
                    key={s.id}
                    className="hover:bg-white/[0.02] transition-colors cursor-pointer"
                    style={{ borderBottom: i < filtered.length - 1 ? '1px solid rgba(255,255,255,0.03)' : 'none' }}
                    onClick={() => viewResult(s)}
                  >
                    <td className="px-6 py-4 text-xs text-slate-600 font-mono">#{s.id.slice(-6).padStart(6, '0')}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-slate-300">
                        {s.type === 'email' && <MailIcon size={14} className="text-blue-400" />}
                        {s.type === 'photo' && <CameraIcon size={14} className="text-purple-400" />}
                        {s.type === 'sms'   && <MessageIcon size={14} className="text-cyan-400" />}
                        <span className="capitalize">{s.type}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-400 max-w-[180px] truncate">{s.target}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 max-w-[60px] h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${s.score}%`,
                              background: s.score > 70 ? '#ef4444' : s.score > 30 ? '#f97316' : '#22c55e',
                            }}
                          />
                        </div>
                        <span
                          className="text-sm font-bold"
                          style={{ color: s.score > 70 ? '#ef4444' : s.score > 30 ? '#f97316' : '#22c55e' }}
                        >
                          {s.score}/100
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge verdict={s.verdict} />
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500 whitespace-nowrap">{formatDate(s.timestamp)}</td>
                    <td className="px-6 py-4">
                      <button
                        onClick={e => { e.stopPropagation(); viewResult(s); }}
                        className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors"
                      >
                        <EyeIcon size={13} /> View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
