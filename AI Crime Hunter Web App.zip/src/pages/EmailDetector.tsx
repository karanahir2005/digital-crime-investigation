import { useState } from 'react';
import { useNav } from '@/context/NavContext';
import { MailIcon, UploadIcon, ScanIcon, WorkflowSteps } from '@/components/ui';

const WORKFLOW = [
  { label: 'Email Input', state: 'done' as const },
  { label: 'Data Extraction', state: 'done' as const },
  { label: 'Sender & Header Check', state: 'active' as const },
  { label: 'URL & Domain Check', state: 'pending' as const },
  { label: 'Content Analysis', state: 'pending' as const },
  { label: 'AI Threat Analysis', state: 'pending' as const },
  { label: 'Risk Score', state: 'pending' as const },
  { label: 'Final Result', state: 'pending' as const },
];

export default function EmailDetector() {
  const { startScan } = useNav();
  const [sender, setSender] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [dragging, setDragging] = useState(false);

  function handleAnalyze(e: React.FormEvent) {
    e.preventDefault();
    startScan('email');
  }

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in-up">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)' }}
          >
            <MailIcon size={20} className="text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">Email Threat Detector</h1>
            <p className="text-sm text-slate-400">Check an email for phishing, scams and suspicious activity.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleAnalyze}>
            <div
              className="rounded-2xl p-6 mb-5"
              style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
            >
              <h2 className="text-sm font-semibold text-slate-300 mb-5 uppercase tracking-wider">Email Details</h2>

              <div className="flex flex-col gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Sender Email</label>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="e.g. support@suspicious-domain.com"
                    value={sender}
                    onChange={e => setSender(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Subject Line</label>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="e.g. Urgent: Your account has been compromised"
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Email Content</label>
                  <textarea
                    className="input-field"
                    style={{ minHeight: 180, resize: 'vertical' }}
                    placeholder="Paste the full email body here..."
                    value={body}
                    onChange={e => setBody(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Drag-and-drop area */}
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={e => { e.preventDefault(); setDragging(false); startScan('email'); }}
              className="rounded-2xl flex flex-col items-center justify-center gap-3 p-8 mb-5 cursor-pointer transition-all"
              style={{
                border: `2px dashed ${dragging ? 'rgba(59,130,246,0.6)' : 'rgba(255,255,255,0.1)'}`,
                background: dragging ? 'rgba(59,130,246,0.05)' : 'transparent',
              }}
              onClick={() => {}}
            >
              <UploadIcon size={28} className={dragging ? 'text-blue-400' : 'text-slate-600'} />
              <div className="text-center">
                <p className="text-sm font-medium text-slate-400">Drop your email file here</p>
                <p className="text-xs text-slate-600 mt-1">Supported: .EML &nbsp;·&nbsp; .TXT &nbsp;·&nbsp; .PDF</p>
              </div>
              <button
                type="button"
                className="btn-outline text-xs px-4 py-2"
              >
                Browse Files
              </button>
            </div>

            <button
              type="submit"
              className="btn-primary w-full flex items-center justify-center gap-2"
              style={{ paddingTop: 15, paddingBottom: 15, borderRadius: 14, fontSize: 15 }}
            >
              <ScanIcon size={18} />
              ANALYZE EMAIL
            </button>
          </form>
        </div>

        {/* Workflow sidebar */}
        <div className="flex flex-col gap-5">
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <h3 className="text-sm font-semibold text-slate-300 mb-4 uppercase tracking-wider">Analysis Workflow</h3>
            <WorkflowSteps steps={WORKFLOW} />
          </div>

          {/* Tips */}
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(59,130,246,0.05)', border: '1px solid rgba(59,130,246,0.15)' }}
          >
            <h3 className="text-sm font-semibold text-blue-300 mb-3">What we check</h3>
            <ul className="flex flex-col gap-2">
              {[
                'Sender domain verification',
                'Reply-To header analysis',
                'Embedded URL scanning',
                'Urgency & pressure language',
                'Credential request detection',
                'Spoofing patterns',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-1 h-1 rounded-full bg-blue-400 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
