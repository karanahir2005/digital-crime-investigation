import { useState } from 'react';
import { useNav, formatDate, type ScanResult } from '@/context/NavContext';
import { StatusBadge, MailIcon, CameraIcon, MessageIcon, ScanIcon, UploadIcon, ArrowRightIcon, ShieldIcon, AlertIcon, CheckIcon, EyeIcon } from '@/components/ui';

function StatCard({ label, value, icon, color, trend }: {
  label: string; value: number | string; icon: React.ReactNode;
  color: string; trend?: string;
}) {
  return (
    <div
      className="rounded-2xl p-5 flex items-start gap-4"
      style={{ background: 'rgba(14,22,45,0.85)', border: '1px solid rgba(255,255,255,0.07)' }}
    >
      <div
        className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}18`, border: `1px solid ${color}30` }}
      >
        <span style={{ color }}>{icon}</span>
      </div>
      <div className="min-w-0">
        <p className="text-2xl font-bold text-white">{value.toLocaleString()}</p>
        <p className="text-xs text-slate-500 mt-0.5">{label}</p>
        {trend && <p className="text-xs text-green-400 mt-1">{trend}</p>}
      </div>
    </div>
  );
}

interface DetectionCardProps {
  type: 'email' | 'photo' | 'sms';
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
  count: number;
  onClick: () => void;
}

function DetectionCard({ icon, title, description, color, count, onClick }: DetectionCardProps) {
  return (
    <button
      onClick={onClick}
      className="card-hover text-left rounded-2xl p-7 flex flex-col gap-5 group"
      style={{
        background: 'rgba(14,22,45,0.9)',
        border: '1px solid rgba(255,255,255,0.07)',
        boxShadow: '0 4px 24px rgba(0,0,0,0.3)',
      }}
    >
      <div className="flex items-start justify-between">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center"
          style={{
            background: `linear-gradient(135deg, ${color}22, ${color}10)`,
            border: `1.5px solid ${color}35`,
            boxShadow: `0 0 20px ${color}15`,
          }}
        >
          <span style={{ color }}>{icon}</span>
        </div>
        <span
          className="text-xs font-medium px-2 py-1 rounded-full"
          style={{ background: `${color}12`, color, border: `1px solid ${color}25` }}
        >
          {count} scans
        </span>
      </div>

      <div>
        <h3 className="text-lg font-bold text-white mb-2">{title}</h3>
        <p className="text-sm text-slate-400 leading-relaxed">{description}</p>
      </div>

      <div
        className="flex items-center gap-2 text-sm font-semibold transition-all duration-200"
        style={{ color }}
      >
        Analyze Now
        <ArrowRightIcon size={16} className="group-hover:translate-x-1 transition-transform" />
      </div>
    </button>
  );
}

export default function Dashboard() {
  const { navigate, startScan, history, user } = useNav();
  const [quickText, setQuickText] = useState('');

  const total = history.length;
  const safe = history.filter(s => s.verdict === 'safe').length;
  const suspicious = history.filter(s => s.verdict === 'suspicious').length;
  const highRisk = history.filter(s => s.verdict === 'high-risk').length;
  const recent = history.slice(0, 5);

  function handleQuickAnalyze() {
    if (!quickText.trim()) return;
    startScan('email');
  }

  function openResult(r: ScanResult) {
    navigate('result');
  }

  return (
    <div className="p-8 max-w-7xl mx-auto fade-in-up">
      {/* Hero heading */}
      <div className="mb-8">
        <p className="text-sm text-cyan-400 font-medium mb-1">Welcome back, {user.name.split(' ')[0]} —</p>
        <h1 className="text-3xl font-black text-white mb-2">AI Crime Detection Dashboard</h1>
        <p className="text-slate-400">Detect suspicious emails, photos and SMS messages with AI-powered analysis.</p>
      </div>

      {/* 3 main detection cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <DetectionCard
          type="email"
          icon={<MailIcon size={28} />}
          title="Email Detection"
          description="Analyze suspicious emails for phishing, scams and malicious content with AI."
          color="#3b82f6"
          count={history.filter(h => h.type === 'email').length}
          onClick={() => navigate('email')}
        />
        <DetectionCard
          type="photo"
          icon={<CameraIcon size={28} />}
          title="Photo Detection"
          description="Analyze images, screenshots and visual content for suspicious or fraudulent information."
          color="#8b5cf6"
          count={history.filter(h => h.type === 'photo').length}
          onClick={() => navigate('photo')}
        />
        <DetectionCard
          type="sms"
          icon={<MessageIcon size={28} />}
          title="SMS Detection"
          description="Check SMS messages for scams, phishing links and social-engineering attacks."
          color="#06b6d4"
          count={history.filter(h => h.type === 'sms').length}
          onClick={() => navigate('sms')}
        />
      </div>

      {/* Quick Analyze */}
      <div
        className="rounded-2xl p-6 mb-8"
        style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
      >
        <h2 className="text-base font-bold text-white mb-1">Quick Analyze</h2>
        <p className="text-sm text-slate-400 mb-4">Paste suspicious content or upload a file to start an AI scan.</p>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <ScanIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={quickText}
              onChange={e => setQuickText(e.target.value)}
              placeholder="Paste suspicious text, email content, SMS or URL..."
              className="input-field pl-9"
              onKeyDown={e => e.key === 'Enter' && handleQuickAnalyze()}
            />
          </div>
          <button onClick={handleQuickAnalyze} className="btn-primary flex items-center gap-2 whitespace-nowrap">
            <ScanIcon size={15} /> Analyze
          </button>
          <button className="btn-outline flex items-center gap-2 whitespace-nowrap">
            <UploadIcon size={15} /> Upload File
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Total Scans" value={1248} icon={<ScanIcon size={18} />} color="#3b82f6" trend="↑ 12% this week" />
        <StatCard label="Safe" value={823} icon={<CheckIcon size={18} />} color="#22c55e" />
        <StatCard label="Suspicious" value={286} icon={<AlertIcon size={18} />} color="#f97316" />
        <StatCard label="High Risk" value={139} icon={<ShieldIcon size={18} />} color="#ef4444" />
      </div>

      {/* Recent Scans */}
      <div
        className="rounded-2xl overflow-hidden"
        style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
          <h2 className="text-base font-bold text-white">Recent Scans</h2>
          <button
            onClick={() => navigate('history')}
            className="text-sm text-blue-400 hover:text-blue-300 transition-colors font-medium"
          >
            View all →
          </button>
        </div>

        {recent.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <ScanIcon size={40} className="text-slate-700 mb-4" />
            <p className="text-slate-400 font-medium mb-1">No scans yet</p>
            <p className="text-sm text-slate-600 mb-5">Your analyzed emails, photos and SMS messages will appear here.</p>
            <button onClick={() => navigate('email')} className="btn-primary text-sm">
              Start Your First Scan
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  {['Type', 'Target', 'Result', 'Risk Score', 'Date', 'Action'].map(h => (
                    <th key={h} className="text-left px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recent.map((s, i) => (
                  <tr
                    key={s.id}
                    className="hover:bg-white/[0.02] transition-colors"
                    style={{ borderBottom: i < recent.length - 1 ? '1px solid rgba(255,255,255,0.03)' : 'none' }}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-slate-300">
                        {s.type === 'email' && <MailIcon size={14} className="text-blue-400" />}
                        {s.type === 'photo' && <CameraIcon size={14} className="text-purple-400" />}
                        {s.type === 'sms'   && <MessageIcon size={14} className="text-cyan-400" />}
                        <span className="capitalize">{s.type}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-400 max-w-[180px] truncate">{s.target}</td>
                    <td className="px-6 py-4">
                      <StatusBadge verdict={s.verdict} />
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className="text-sm font-bold"
                        style={{ color: s.score > 70 ? '#ef4444' : s.score > 30 ? '#f97316' : '#22c55e' }}
                      >
                        {s.score}/100
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">{formatDate(s.timestamp)}</td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => openResult(s)}
                        className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors"
                      >
                        <EyeIcon size={13} /> View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
