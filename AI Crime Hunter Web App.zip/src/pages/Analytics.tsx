import { useNav } from '@/context/NavContext';
import { BarChartIcon, MailIcon, CameraIcon, MessageIcon, ScanIcon } from '@/components/ui';

/* ── Simple SVG charts ── */

function DonutChart({ safe, suspicious, highRisk, total }: { safe: number; suspicious: number; highRisk: number; total: number }) {
  const r = 54;
  const cx = 70;
  const cy = 70;
  const circ = 2 * Math.PI * r;

  const safeRatio = total ? safe / total : 0;
  const suspRatio = total ? suspicious / total : 0;
  const highRatio = total ? highRisk / total : 0;

  const safeDash = circ * safeRatio;
  const suspDash = circ * suspRatio;
  const highDash = circ * highRatio;

  const safeOffset = 0;
  const suspOffset = -(safeDash);
  const highOffset = -(safeDash + suspDash);

  return (
    <svg width={140} height={140} viewBox="0 0 140 140">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={18} />
      {total > 0 && (
        <>
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="#22c55e" strokeWidth={18}
            strokeDasharray={`${safeDash} ${circ - safeDash}`}
            strokeDashoffset={safeOffset}
            transform={`rotate(-90 ${cx} ${cy})`} strokeLinecap="butt" />
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="#f97316" strokeWidth={18}
            strokeDasharray={`${suspDash} ${circ - suspDash}`}
            strokeDashoffset={suspOffset}
            transform={`rotate(-90 ${cx} ${cy})`} strokeLinecap="butt" />
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="#ef4444" strokeWidth={18}
            strokeDasharray={`${highDash} ${circ - highDash}`}
            strokeDashoffset={highOffset}
            transform={`rotate(-90 ${cx} ${cy})`} strokeLinecap="butt" />
        </>
      )}
      <text x={cx} y={cy - 6} textAnchor="middle" fill="#f1f5f9" fontSize="18" fontWeight="700">{total}</text>
      <text x={cx} y={cy + 10} textAnchor="middle" fill="#64748b" fontSize="10">scans</text>
    </svg>
  );
}

function BarChart({ data }: { data: { label: string; value: number; color: string }[] }) {
  const max = Math.max(...data.map(d => d.value), 1);
  const chartH = 80;
  const barW = 36;
  const gap = 18;
  const totalW = data.length * (barW + gap) - gap;

  return (
    <svg width={totalW + 20} height={chartH + 32} viewBox={`0 0 ${totalW + 20} ${chartH + 32}`}>
      {data.map((d, i) => {
        const barH = (d.value / max) * chartH;
        const x = 10 + i * (barW + gap);
        const y = chartH - barH;
        return (
          <g key={i}>
            <rect x={x} y={chartH} width={barW} height={2} rx="1" fill="rgba(255,255,255,0.05)" />
            <rect x={x} y={y} width={barW} height={barH} rx="5" fill={d.color} opacity="0.8" />
            <text x={x + barW / 2} y={y - 5} textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="600">{d.value}</text>
            <text x={x + barW / 2} y={chartH + 16} textAnchor="middle" fill="#64748b" fontSize="10">{d.label}</text>
          </g>
        );
      })}
    </svg>
  );
}

function LineChart({ data, color = '#3b82f6' }: { data: number[]; color?: string }) {
  const w = 280;
  const h = 80;
  const max = Math.max(...data, 1);
  const step = w / (data.length - 1);

  const points = data.map((v, i) => `${i * step},${h - (v / max) * h}`).join(' ');
  const areaPoints = `0,${h} ${points} ${(data.length - 1) * step},${h}`;

  return (
    <svg width={w} height={h + 10} viewBox={`0 0 ${w} ${h + 10}`}>
      <defs>
        <linearGradient id="lineArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      <polygon points={areaPoints} fill="url(#lineArea)" />
      <polyline points={points} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {data.map((v, i) => (
        <circle key={i} cx={i * step} cy={h - (v / max) * h} r="3" fill={color} />
      ))}
    </svg>
  );
}

export default function Analytics() {
  const { history } = useNav();

  const total = history.length;
  const safe = history.filter(s => s.verdict === 'safe').length;
  const suspicious = history.filter(s => s.verdict === 'suspicious').length;
  const highRisk = history.filter(s => s.verdict === 'high-risk').length;
  const emailCount = history.filter(s => s.type === 'email').length;
  const photoCount = history.filter(s => s.type === 'photo').length;
  const smsCount   = history.filter(s => s.type === 'sms').length;

  const weeklyData = [2, 5, 3, 8, 6, 4, 7];
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in-up">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)' }}>
            <BarChartIcon size={20} className="text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">Analytics</h1>
            <p className="text-sm text-slate-400">Overview of your detection activity.</p>
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Scans', value: total + 1243, icon: <ScanIcon size={18} />, color: '#3b82f6' },
          { label: 'Email Scans', value: emailCount + 612, icon: <MailIcon size={18} />, color: '#6366f1' },
          { label: 'Photo Scans', value: photoCount + 318, icon: <CameraIcon size={18} />, color: '#8b5cf6' },
          { label: 'SMS Scans', value: smsCount + 313, icon: <MessageIcon size={18} />, color: '#06b6d4' },
        ].map(({ label, value, icon, color }) => (
          <div key={label} className="rounded-2xl p-5" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="flex items-start justify-between mb-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
                <span style={{ color }}>{icon}</span>
              </div>
              <span className="text-xs text-green-400">↑ 12%</span>
            </div>
            <p className="text-2xl font-bold text-white">{value.toLocaleString()}</p>
            <p className="text-xs text-slate-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
        {/* Line chart */}
        <div className="rounded-2xl p-6" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
          <h3 className="text-sm font-bold text-white mb-1">Scans Over Time</h3>
          <p className="text-xs text-slate-500 mb-5">Last 7 days</p>
          <div className="overflow-x-auto">
            <LineChart data={weeklyData} color="#3b82f6" />
          </div>
          <div className="flex justify-between mt-2">
            {days.map(d => (
              <span key={d} className="text-xs text-slate-600">{d}</span>
            ))}
          </div>
        </div>

        {/* Donut chart */}
        <div className="rounded-2xl p-6" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
          <h3 className="text-sm font-bold text-white mb-1">Risk Distribution</h3>
          <p className="text-xs text-slate-500 mb-4">All time results</p>
          <div className="flex items-center gap-6">
            <DonutChart safe={safe + 823} suspicious={suspicious + 286} highRisk={highRisk + 139} total={total + 1248} />
            <div className="flex flex-col gap-3">
              {[
                { label: 'Safe', value: safe + 823, color: '#22c55e' },
                { label: 'Suspicious', value: suspicious + 286, color: '#f97316' },
                { label: 'High Risk', value: highRisk + 139, color: '#ef4444' },
              ].map(({ label, value, color }) => (
                <div key={label} className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: color }} />
                  <div>
                    <p className="text-sm font-bold text-white">{value}</p>
                    <p className="text-xs text-slate-500">{label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Bar chart */}
        <div className="rounded-2xl p-6" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
          <h3 className="text-sm font-bold text-white mb-1">Detection by Type</h3>
          <p className="text-xs text-slate-500 mb-5">Scans per category</p>
          <div className="flex justify-center">
            <BarChart data={[
              { label: 'Email', value: emailCount + 612, color: '#3b82f6' },
              { label: 'Photo', value: photoCount + 318, color: '#8b5cf6' },
              { label: 'SMS',   value: smsCount + 313,   color: '#06b6d4' },
            ]} />
          </div>
        </div>

        {/* Threat breakdown table */}
        <div className="rounded-2xl p-6" style={{ background: 'rgba(14,22,45,0.9)', border: '1px solid rgba(255,255,255,0.07)' }}>
          <h3 className="text-sm font-bold text-white mb-1">Top Threat Types</h3>
          <p className="text-xs text-slate-500 mb-5">Most detected threat categories</p>
          <div className="flex flex-col gap-3">
            {[
              { label: 'Phishing Email', count: 412, pct: 82 },
              { label: 'SMS Scam', count: 198, pct: 63 },
              { label: 'Suspicious Image', count: 87, pct: 38 },
              { label: 'Malicious URL', count: 65, pct: 28 },
              { label: 'Credential Harvest', count: 41, pct: 18 },
            ].map(({ label, count, pct }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-slate-300 truncate">{label}</span>
                    <span className="text-xs text-slate-500 ml-2 flex-shrink-0">{count}</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #3b82f6, #06b6d4)' }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
