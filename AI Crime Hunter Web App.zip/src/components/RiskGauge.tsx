import { getScoreColor } from '@/context/NavContext';

interface RiskGaugeProps {
  score: number;
  size?: number;
  showLabel?: boolean;
}

export default function RiskGauge({ score, size = 140, showLabel = true }: RiskGaugeProps) {
  const radius = (size - 20) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedScore = Math.max(0, Math.min(100, score));
  const fillRatio = clampedScore / 100;
  const strokeDashoffset = circumference * (1 - fillRatio);
  const color = getScoreColor(clampedScore);

  const verdict =
    clampedScore <= 30 ? 'SAFE' :
    clampedScore <= 70 ? 'SUSPICIOUS' :
    'HIGH RISK';

  return (
    <div className="flex flex-col items-center gap-2">
      <div style={{ position: 'relative', width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          {/* Track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.06)"
            strokeWidth="12"
          />
          {/* Fill */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={`${circumference}`}
            strokeDashoffset={strokeDashoffset}
            style={{ filter: `drop-shadow(0 0 6px ${color}80)`, transition: 'stroke-dashoffset 0.8s ease-out' }}
          />
        </svg>
        {/* Center text */}
        <div
          style={{
            position: 'absolute', inset: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
          }}
        >
          <span style={{ color, fontSize: size * 0.22, fontWeight: 800, lineHeight: 1 }}>
            {clampedScore}
          </span>
          <span style={{ color: 'rgba(148,163,184,0.8)', fontSize: size * 0.1, marginTop: 2 }}>
            / 100
          </span>
        </div>
      </div>
      {showLabel && (
        <span
          className="text-sm font-bold tracking-widest px-3 py-1 rounded-full"
          style={{
            color,
            background: `${color}18`,
            border: `1px solid ${color}30`,
          }}
        >
          {verdict}
        </span>
      )}
    </div>
  );
}
