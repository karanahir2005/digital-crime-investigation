import type { ReactNode } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-full overflow-hidden">
      <Sidebar />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header />
        <main
          className="flex-1 overflow-y-auto"
          style={{ background: 'linear-gradient(160deg, #080e1d 0%, #060b18 100%)' }}
        >
          {children}
        </main>
      </div>
    </div>
  );
}
