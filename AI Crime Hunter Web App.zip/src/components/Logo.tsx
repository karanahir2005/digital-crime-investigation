interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  collapsed?: boolean;
}

export default function Logo({ size = 'md', collapsed = false }: LogoProps) {
  const iconSize = size === 'sm' ? 32 : size === 'lg' ? 56 : 42;
  const textSize = size === 'sm' ? 'text-sm' : size === 'lg' ? 'text-xl' : 'text-base';

  return (
    <div className="flex items-center gap-3">
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 56 56"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ flexShrink: 0 }}
      >
        <defs>
          <linearGradient id="logoGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#06b6d4" />
          </linearGradient>
          <linearGradient id="logoGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1d4ed8" />
            <stop offset="100%" stopColor="#0891b2" />
          </linearGradient>
          <clipPath id="circleClip">
            <circle cx="28" cy="28" r="26" />
          </clipPath>
        </defs>

        {/* Outer ring */}
        <circle cx="28" cy="28" r="27" fill="rgba(8,14,29,0.9)" stroke="url(#logoGrad1)" strokeWidth="1.5" />

        {/* Circuit board background lines */}
        <g clipPath="url(#circleClip)" stroke="rgba(59,130,246,0.18)" strokeWidth="0.8">
          <line x1="2" y1="14" x2="12" y2="14" />
          <line x1="12" y1="14" x2="12" y2="20" />
          <line x1="44" y1="14" x2="54" y2="14" />
          <line x1="44" y1="14" x2="44" y2="20" />
          <line x1="2" y1="42" x2="12" y2="42" />
          <line x1="12" y1="42" x2="12" y2="36" />
          <line x1="44" y1="42" x2="54" y2="42" />
          <line x1="44" y1="42" x2="44" y2="36" />
          <circle cx="12" cy="14" r="1.2" fill="rgba(59,130,246,0.4)" stroke="none" />
          <circle cx="44" cy="14" r="1.2" fill="rgba(59,130,246,0.4)" stroke="none" />
          <circle cx="12" cy="42" r="1.2" fill="rgba(59,130,246,0.4)" stroke="none" />
          <circle cx="44" cy="42" r="1.2" fill="rgba(59,130,246,0.4)" stroke="none" />
        </g>

        {/* Fox head body */}
        <path d="M28 38 L18 26 Q16 22 20 20 L28 22 L36 20 Q40 22 38 26 Z"
          fill="url(#logoGrad2)" opacity="0.9" />

        {/* Fox ears */}
        <path d="M20 20 L15 11 L23 17 Z" fill="url(#logoGrad1)" />
        <path d="M36 20 L41 11 L33 17 Z" fill="url(#logoGrad1)" />

        {/* Inner ear highlight */}
        <path d="M20 20 L16.5 13 L22 17.5 Z" fill="rgba(6,182,212,0.5)" />
        <path d="M36 20 L39.5 13 L34 17.5 Z" fill="rgba(6,182,212,0.5)" />

        {/* Camera/eye aperture outer */}
        <circle cx="28" cy="26" r="7" fill="rgba(8,14,29,0.8)" stroke="url(#logoGrad1)" strokeWidth="1.5" />

        {/* Camera lens inner rings */}
        <circle cx="28" cy="26" r="4.5" fill="none" stroke="rgba(59,130,246,0.5)" strokeWidth="0.8" />
        <circle cx="28" cy="26" r="2.5" fill="url(#logoGrad1)" opacity="0.9" />
        <circle cx="28" cy="26" r="1" fill="white" opacity="0.8" />

        {/* Lens glint */}
        <circle cx="26.5" cy="24.5" r="0.7" fill="white" opacity="0.6" />

        {/* Fox snout dot */}
        <ellipse cx="28" cy="33" rx="1.8" ry="1.2" fill="rgba(6,182,212,0.7)" />

        {/* Circuit nodes bottom */}
        <g stroke="rgba(59,130,246,0.35)" strokeWidth="0.8" strokeDasharray="2,2">
          <line x1="18" y1="38" x2="10" y2="38" />
          <line x1="38" y1="38" x2="46" y2="38" />
        </g>
        <circle cx="10" cy="38" r="1" fill="rgba(6,182,212,0.5)" stroke="none" />
        <circle cx="46" cy="38" r="1" fill="rgba(6,182,212,0.5)" stroke="none" />
      </svg>

      {!collapsed && (
        <div className="leading-tight">
          <div className={`font-black tracking-widest ${textSize}`} style={{ color: '#f1f5f9', letterSpacing: '0.12em' }}>
            AI CRIME
          </div>
          <div
            className={`font-black tracking-widest ${textSize}`}
            style={{
              background: 'linear-gradient(90deg, #3b82f6, #06b6d4)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              letterSpacing: '0.12em',
            }}
          >
            HUNTER
          </div>
        </div>
      )}
    </div>
  );
}
