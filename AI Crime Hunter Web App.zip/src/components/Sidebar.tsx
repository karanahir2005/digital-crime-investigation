import Logo from './Logo';
import {
  HomeIcon, MailIcon, CameraIcon, MessageIcon,
  WifiIcon, HistoryIcon, BarChartIcon,
  UserIcon, SettingsIcon, HelpIcon, LogOutIcon,
  ChevronRightIcon, ShieldIcon,
} from './ui';
import { useNav, type Page } from '@/context/NavContext';

interface NavItem {
  id: Page;
  label: string;
  icon: React.ReactNode;
  children?: { id: Page; label: string }[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <HomeIcon /> },
  {
    id: 'email', label: 'Detection', icon: <ShieldIcon />,
    children: [
      { id: 'email', label: 'Email Detector' },
      { id: 'photo', label: 'Photo Detector' },
      { id: 'sms',   label: 'SMS Detector' },
    ],
  },
  { id: 'wifi',      label: 'Wi-Fi Scanner', icon: <WifiIcon /> },
  { id: 'history',   label: 'Scan History',  icon: <HistoryIcon /> },
  { id: 'analytics', label: 'Analytics',     icon: <BarChartIcon /> },
  { id: 'settings',  label: 'Settings',      icon: <SettingsIcon /> },
];

const DETECT_PAGES: Page[] = ['email', 'photo', 'sms'];

export default function Sidebar() {
  const { page, navigate, user, logout, sidebarCollapsed } = useNav();

  const isDetectionActive = DETECT_PAGES.includes(page);

  function isActive(id: Page) {
    return page === id || (id === 'email' && isDetectionActive);
  }

  return (
    <aside
      className="flex flex-col h-full transition-all duration-300"
      style={{
        width: sidebarCollapsed ? 68 : 240,
        background: 'linear-gradient(180deg, #060c1a 0%, #080e1d 100%)',
        borderRight: '1px solid rgba(255,255,255,0.05)',
        flexShrink: 0,
      }}
    >
      {/* Logo */}
      <div className="px-4 pt-6 pb-5">
        <Logo collapsed={sidebarCollapsed} size="sm" />
      </div>

      <div className="h-px mx-4" style={{ background: 'rgba(255,255,255,0.05)' }} />

      {/* Nav items */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        {NAV_ITEMS.map((item) => {
          const active = isActive(item.id);
          const hasChildren = !!item.children;
          const childrenExpanded = hasChildren && isDetectionActive;

          return (
            <div key={item.id} className="mb-0.5">
              <button
                onClick={() => navigate(hasChildren ? 'email' : item.id)}
                className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150 group ${
                  active
                    ? 'sidebar-active text-blue-300'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <span className={active ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300'}>
                  {item.icon}
                </span>
                {!sidebarCollapsed && (
                  <>
                    <span className="flex-1 text-left">{item.label}</span>
                    {hasChildren && (
                      <ChevronRightIcon
                        size={14}
                        className={`transition-transform ${childrenExpanded ? 'rotate-90' : ''}`}
                      />
                    )}
                  </>
                )}
              </button>

              {/* Children */}
              {hasChildren && childrenExpanded && !sidebarCollapsed && (
                <div className="ml-7 mt-0.5 flex flex-col gap-0.5">
                  {item.children!.map((child) => (
                    <button
                      key={child.id}
                      onClick={() => navigate(child.id)}
                      className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-all duration-150 ${
                        page === child.id
                          ? 'text-cyan-300 bg-cyan-500/10'
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full" style={{
                        background: page === child.id ? '#06b6d4' : 'rgba(255,255,255,0.2)',
                        flexShrink: 0,
                      }} />
                      {child.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="h-px mx-4" style={{ background: 'rgba(255,255,255,0.05)' }} />

      {/* Bottom actions */}
      <div className="px-2 py-4 flex flex-col gap-0.5">
        <button
          onClick={() => navigate('profile')}
          className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
            page === 'profile'
              ? 'sidebar-active text-blue-300'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <UserIcon size={18} className={page === 'profile' ? 'text-blue-400' : 'text-slate-500'} />
          {!sidebarCollapsed && <span>Profile</span>}
        </button>

        <button className="w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-400 hover:text-slate-200 hover:bg-white/5 transition-all">
          <HelpIcon size={18} className="text-slate-500" />
          {!sidebarCollapsed && <span>Help & Support</span>}
        </button>

        <button
          onClick={logout}
          className="w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/5 transition-all"
        >
          <LogOutIcon size={18} className="text-slate-500" />
          {!sidebarCollapsed && <span>Logout</span>}
        </button>
      </div>

      {/* User card */}
      {!sidebarCollapsed && (
        <div className="px-3 pb-4">
          <div
            className="flex items-center gap-3 p-3 rounded-xl"
            style={{ background: 'rgba(59,130,246,0.06)', border: '1px solid rgba(59,130,246,0.12)' }}
          >
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #3b82f6, #06b6d4)' }}
            >
              {user.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-slate-200 truncate">{user.name}</p>
              <p className="text-xs text-slate-500 truncate">{user.role}</p>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
