import { useState } from 'react';
import { SearchIcon, BellIcon, MenuIcon, ZapIcon } from './ui';
import { useNav } from '@/context/NavContext';

const PAGE_TITLES: Record<string, string> = {
  dashboard: 'Dashboard',
  email: 'Email Detector',
  photo: 'Photo Detector',
  sms: 'SMS Detector',
  wifi: 'Wi-Fi Scanner',
  history: 'Scan History',
  analytics: 'Analytics',
  profile: 'Profile',
  settings: 'Settings',
  result: 'Scan Result',
  processing: 'AI Analysis',
};

export default function Header() {
  const { page, user, toggleSidebar } = useNav();
  const [notifOpen, setNotifOpen] = useState(false);
  const title = PAGE_TITLES[page] ?? 'AI Crime Hunter';

  return (
    <header
      className="flex items-center gap-4 px-6 py-3.5 relative z-20 flex-shrink-0"
      style={{
        background: 'rgba(8,14,29,0.95)',
        borderBottom: '1px solid rgba(255,255,255,0.05)',
        backdropFilter: 'blur(8px)',
      }}
    >
      {/* Sidebar toggle */}
      <button
        onClick={toggleSidebar}
        className="text-slate-400 hover:text-slate-200 transition-colors p-1 rounded-lg hover:bg-white/5"
      >
        <MenuIcon size={20} />
      </button>

      {/* Page title */}
      <div className="flex-shrink-0">
        <h1 className="text-base font-semibold text-slate-100">{title}</h1>
      </div>

      {/* Search — center */}
      <div className="flex-1 max-w-md mx-auto relative">
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <SearchIcon size={15} className="text-slate-500 flex-shrink-0" />
          <input
            type="text"
            placeholder="Search scans, threats..."
            className="bg-transparent flex-1 outline-none text-slate-300 placeholder-slate-600 text-sm"
          />
        </div>
      </div>

      {/* Right section */}
      <div className="flex items-center gap-3 ml-auto flex-shrink-0">
        {/* AI Status */}
        <div
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
          style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}
        >
          <ZapIcon size={11} className="text-green-400" />
          <span className="text-green-400">AI ONLINE</span>
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block animate-pulse" />
        </div>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen(v => !v)}
            className="relative text-slate-400 hover:text-slate-200 transition-colors p-2 rounded-lg hover:bg-white/5"
          >
            <BellIcon size={18} />
            <span
              className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-500 border-2"
              style={{ borderColor: '#080e1d' }}
            />
          </button>

          {notifOpen && (
            <div
              className="absolute right-0 top-full mt-2 w-72 rounded-2xl p-4 z-50"
              style={{ background: '#0d1628', border: '1px solid rgba(255,255,255,0.08)', boxShadow: '0 20px 60px rgba(0,0,0,0.6)' }}
            >
              <p className="text-sm font-semibold text-slate-200 mb-3">Notifications</p>
              <div className="flex flex-col gap-2">
                {[
                  { text: 'New high-risk email detected', time: '2m ago', color: '#ef4444' },
                  { text: 'Photo scan completed', time: '1h ago', color: '#3b82f6' },
                  { text: 'System update available', time: '3h ago', color: '#6366f1' },
                ].map((n, i) => (
                  <div key={i} className="flex items-start gap-3 p-2 rounded-lg hover:bg-white/5 cursor-pointer">
                    <span className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: n.color }} />
                    <div>
                      <p className="text-xs text-slate-300">{n.text}</p>
                      <p className="text-xs text-slate-600 mt-0.5">{n.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User avatar */}
        <button
          className="flex items-center gap-2 rounded-xl px-2 py-1.5 hover:bg-white/5 transition-colors"
        >
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #3b82f6, #06b6d4)' }}
          >
            {user.name.charAt(0)}
          </div>
          <span className="text-sm text-slate-300 hidden md:block">{user.name.split(' ')[0]}</span>
        </button>
      </div>
    </header>
  );
}
