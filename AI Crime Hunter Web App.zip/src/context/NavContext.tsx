import { createContext, useContext, useState, ReactNode } from 'react';

export type Page =
  | 'login' | 'register' | 'dashboard'
  | 'email' | 'photo' | 'sms'
  | 'wifi' | 'history' | 'analytics'
  | 'profile' | 'settings'
  | 'processing' | 'result';

export interface ScanResult {
  id: string;
  type: 'email' | 'photo' | 'sms';
  target: string;
  score: number;
  verdict: 'safe' | 'suspicious' | 'high-risk';
  confidence: number;
  threatType: string;
  indicators: string[];
  explanation: string;
  recommendation: string;
  timestamp: Date;
}

export interface User {
  name: string;
  email: string;
  role: string;
  joinDate: string;
}

interface NavContextType {
  page: Page;
  navigate: (page: Page) => void;
  processingType: 'email' | 'photo' | 'sms' | null;
  startScan: (type: 'email' | 'photo' | 'sms') => void;
  currentResult: ScanResult | null;
  setCurrentResult: (r: ScanResult | null) => void;
  history: ScanResult[];
  addToHistory: (r: ScanResult) => void;
  user: User;
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
}

const NavContext = createContext<NavContextType | null>(null);

const MOCK_HISTORY: ScanResult[] = [
  {
    id: '1', type: 'email', target: 'support@paypa1-secure.com',
    score: 91, verdict: 'high-risk', confidence: 96,
    threatType: 'Phishing Email',
    indicators: ['Suspicious sender domain', 'Reply-To address mismatch', 'Urgent language detected', 'Malicious URL embedded', 'Credential request detected'],
    explanation: "Multiple phishing indicators were detected in this email. The sender domain appears inconsistent with the claimed organization and the message attempts to create urgency while requesting sensitive information.",
    recommendation: "Do not open links, download attachments or provide personal information.",
    timestamp: new Date(Date.now() - 3_600_000),
  },
  {
    id: '2', type: 'photo', target: 'screenshot_01.png',
    score: 67, verdict: 'suspicious', confidence: 89,
    threatType: 'Suspicious Image Content',
    indicators: ['Suspicious QR code detected', 'Potential phishing page visible', 'Suspicious branding elements', 'Sensitive information request visible'],
    explanation: "The image contains elements commonly found in phishing attempts, including a suspicious QR code and branding that mimics a legitimate organization.",
    recommendation: "Do not interact with links or provide sensitive information until verified.",
    timestamp: new Date(Date.now() - 7_200_000),
  },
  {
    id: '3', type: 'sms', target: '+91 98765 XXXXX',
    score: 87, verdict: 'high-risk', confidence: 94,
    threatType: 'SMS Phishing Scam',
    indicators: ['Suspicious link detected', 'Urgency language detected', 'Prize/reward claim present', 'Request for personal information', 'Suspicious sender number'],
    explanation: "This message contains multiple indicators commonly associated with phishing or scam campaigns including urgency triggers and suspicious links.",
    recommendation: "Do not open links, download attachments or provide personal information.",
    timestamp: new Date(Date.now() - 86_400_000),
  },
  {
    id: '4', type: 'email', target: 'newsletter@amazon.com',
    score: 12, verdict: 'safe', confidence: 98,
    threatType: 'Legitimate Email',
    indicators: ['Verified sender domain', 'No suspicious URLs found', 'No credential requests', 'Standard email format'],
    explanation: "This email appears to be a legitimate communication from the claimed organization. No phishing indicators were detected.",
    recommendation: "Content appears safe, but remain cautious.",
    timestamp: new Date(Date.now() - 172_800_000),
  },
  {
    id: '5', type: 'sms', target: '+1-800-FAKE-NUM',
    score: 54, verdict: 'suspicious', confidence: 78,
    threatType: 'Potential Smishing',
    indicators: ['Unusual sender format', 'Shortened URL detected', 'Informal language patterns'],
    explanation: "This SMS shows some indicators of smishing but confidence is moderate. The shortened URL could not be fully resolved.",
    recommendation: "Do not interact with links or provide sensitive information until verified.",
    timestamp: new Date(Date.now() - 259_200_000),
  },
];

export function NavProvider({ children }: { children: ReactNode }) {
  const [page, setPage] = useState<Page>('login');
  const [processingType, setProcessingType] = useState<'email' | 'photo' | 'sms' | null>(null);
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [history, setHistory] = useState<ScanResult[]>(MOCK_HISTORY);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const user: User = {
    name: 'Alex Kumar',
    email: 'alex.kumar@example.com',
    role: 'Security Analyst',
    joinDate: 'January 2024',
  };

  function navigate(newPage: Page) { setPage(newPage); }

  function startScan(type: 'email' | 'photo' | 'sms') {
    setProcessingType(type);
    setPage('processing');
  }

  function addToHistory(r: ScanResult) {
    setHistory(prev => [r, ...prev]);
  }

  function login() { setIsAuthenticated(true); setPage('dashboard'); }
  function logout() { setIsAuthenticated(false); setPage('login'); }
  function toggleSidebar() { setSidebarCollapsed(c => !c); }

  return (
    <NavContext.Provider value={{
      page, navigate, processingType, startScan,
      currentResult, setCurrentResult,
      history, addToHistory,
      user, isAuthenticated, login, logout,
      sidebarCollapsed, toggleSidebar,
    }}>
      {children}
    </NavContext.Provider>
  );
}

export function useNav() {
  const ctx = useContext(NavContext);
  if (!ctx) throw new Error('useNav must be used within NavProvider');
  return ctx;
}

export function getVerdictLabel(v: ScanResult['verdict']) {
  if (v === 'safe') return 'Safe';
  if (v === 'suspicious') return 'Suspicious';
  return 'High Risk';
}

export function getScoreColor(score: number) {
  if (score <= 30) return '#22c55e';
  if (score <= 70) return '#f97316';
  return '#ef4444';
}

export function formatDate(d: Date): string {
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  if (diff < 60_000) return 'Just now';
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return 'Today';
  if (diff < 172_800_000) return 'Yesterday';
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}
