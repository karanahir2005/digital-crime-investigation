import { NavProvider, useNav } from '@/context/NavContext';
import Layout from '@/components/Layout';

import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Dashboard from '@/pages/Dashboard';
import EmailDetector from '@/pages/EmailDetector';
import PhotoDetector from '@/pages/PhotoDetector';
import SMSDetector from '@/pages/SMSDetector';
import WiFiScanner from '@/pages/WiFiScanner';
import ScanHistory from '@/pages/ScanHistory';
import Analytics from '@/pages/Analytics';
import AIProcessing from '@/pages/AIProcessing';
import ScanResult from '@/pages/ScanResult';
import Profile from '@/pages/Profile';
import Settings from '@/pages/Settings';

const AUTH_PAGES = ['login', 'register'];
const FULL_SCREEN_PAGES = ['processing'];

function AppRouter() {
  const { page } = useNav();

  if (AUTH_PAGES.includes(page)) {
    return page === 'login' ? <Login /> : <Register />;
  }

  if (FULL_SCREEN_PAGES.includes(page)) {
    return <AIProcessing />;
  }

  const content = (() => {
    switch (page) {
      case 'dashboard': return <Dashboard />;
      case 'email':     return <EmailDetector />;
      case 'photo':     return <PhotoDetector />;
      case 'sms':       return <SMSDetector />;
      case 'wifi':      return <WiFiScanner />;
      case 'history':   return <ScanHistory />;
      case 'analytics': return <Analytics />;
      case 'result':    return <ScanResult />;
      case 'profile':   return <Profile />;
      case 'settings':  return <Settings />;
      default:          return <Dashboard />;
    }
  })();

  return <Layout>{content}</Layout>;
}

export default function App() {
  return (
    <NavProvider>
      <AppRouter />
    </NavProvider>
  );
}
